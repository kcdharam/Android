package com.example.stu_share;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Create extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
    }
}
